#!/usr/bin/env python3
"""
Прогон FormRecommendationAgent на фикстуре «проблемный finance CV (UAE)».
Безопасно: только чтение файла и stdout JSON.

Пример:
  ./venv/bin/python scripts/run_form_recommendation_fixture.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

FIXTURE = ROOT / "tests" / "fixtures" / "form_recommendation_problematic_finance_uae_cv.txt"


def main() -> int:
    if not FIXTURE.is_file():
        print(f"Fixture not found: {FIXTURE}", file=sys.stderr)
        return 1
    text = FIXTURE.read_text(encoding="utf-8")
    from app.form_recommendation_agent import FormRecommendationAgent

    r = FormRecommendationAgent().recommend(text).to_dict()
    facts = r.pop("extracted_facts", None) or {}
    past = facts.get("past_roles") or []
    out = {
        **r,
        "extracted_facts_summary": {
            "desired_position": facts.get("desired_position"),
            "past_roles_sample": past[:5],
            "email": facts.get("email"),
            "location": facts.get("location"),
        },
    }
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
