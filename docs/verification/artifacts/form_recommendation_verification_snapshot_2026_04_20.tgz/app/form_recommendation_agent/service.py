from __future__ import annotations

import re
from typing import Any

from app.resume_form_mapper import (
    is_invalid_keyword_token,
    is_resume_section_title_line,
    is_valid_role_candidate,
    split_resume_sections,
)

from .extractor import ResumeFactExtractor
from .schemas import FormRecommendationResult


ROLE_FAMILY_ALTERNATIVES = {
    "директор по ит": ["CIO", "CTO", "Директор по цифровой трансформации"],
    "директор по цифровой трансформации": ["Директор по ИТ", "CIO", "Директор по инновациям"],
    "генеральный директор": ["Исполнительный директор", "Операционный директор"],
    "исполнительный директор": ["Генеральный директор", "Операционный директор"],
    "операционный директор": ["Исполнительный директор", "Генеральный директор"],
    "коммерческий директор": ["Директор по продажам", "Директор по развитию бизнеса"],
    "директор по продажам": ["Коммерческий директор", "Директор по развитию бизнеса"],
    "директор по развитию бизнеса": ["Коммерческий директор", "Директор по продажам"],
    "финансовый директор": ["Head of Finance", "CFO"],
    "руководитель продукта": ["Head of Product", "Product Owner"],
}

ROLE_TO_INDUSTRY = [
    ("IT / Digital / Product", ["cio", "cto", "директор по ит", "it", "digital", "product", "разработ", "developer"]),
    ("Финансы", ["cfo", "финансов", "finance", "казнач", "ifrs"]),
    ("Продажи / Развитие бизнеса", ["sales", "продаж", "коммерческ", "business development"]),
    ("Операционное управление", ["coo", "операцион", "operations"]),
    ("Производство / Инжиниринг", ["инжинир", "производств", "engineering", "manufacturing"]),
]

KEYWORD_MARKERS = [
    ("цифровая трансформация", 5),
    ("erp", 5),
    ("sap", 5),
    ("postgresql", 5),
    ("redis", 5),
    ("celery", 5),
    ("docker", 5),
    ("kubernetes", 5),
    ("python", 4),
    ("flask", 4),
    ("django", 4),
    ("fastapi", 4),
    ("crm", 4),
    ("ifrs", 5),
    ("fp&a", 5),
    ("gaap", 4),
    ("budgeting", 5),
    ("forecasting", 5),
    ("cash flow", 5),
    ("p&l", 5),
    ("variance analysis", 5),
    ("kpi reporting", 4),
    ("excel", 4),
    ("power query", 4),
    ("power bi", 4),
    ("vba", 4),
    ("financial modelling", 5),
    ("financial modeling", 5),
    ("management reporting", 4),
    ("b2b", 4),
    ("b2c", 4),
    ("управление командой", 2),
    ("стратегическое планирование", 2),
    ("развитие бизнеса", 2),
    ("операционная эффективность", 2),
    ("переговоры", 2),
]

GENERIC_KEYWORDS = {
    "управление командой",
    "стратегическое планирование",
    "развитие бизнеса",
    "операционная эффективность",
    "переговоры",
}


def _is_commercial_profile(primary_role: str) -> bool:
    low = _clean_text(primary_role).lower()
    if not low:
        return False
    return any(
        x in low
        for x in (
            "sales",
            "business development",
            "commercial",
            "account manager",
            "key account",
            "продаж",
            "коммерческ",
            "развитие бизнеса",
        )
    )


def _is_operations_profile(primary_role: str) -> bool:
    low = _clean_text(primary_role).lower()
    if not low:
        return False
    return any(
        x in low
        for x in (
            "operations",
            "operational",
            "coo",
            "операцион",
            "операции",
        )
    )


def _is_product_profile(primary_role: str) -> bool:
    low = _clean_text(primary_role).lower()
    if not low:
        return False
    return any(
        x in low
        for x in (
            "product manager",
            "product owner",
            "head of product",
            "продукт",
        )
    )


def _is_finance_fpa_profile(primary_role: str) -> bool:
    low = _clean_text(primary_role).lower()
    if not low:
        return False
    return any(
        marker in low
        for marker in (
            "fp&a",
            "fpa",
            "finance analyst",
            "financial analyst",
            "financial planning",
            "финансовый аналитик",
            "финанс",
            "бюджет",
            "казначе",
        )
    )


FINANCE_KEYWORD_SEEDS = [
    "fp&a",
    "budgeting",
    "forecasting",
    "cash flow",
    "p&l",
    "variance analysis",
    "kpi reporting",
    "financial modelling",
    "management reporting",
    "ifrs",
    "excel",
    "power query",
    "vba",
]


def _clean_text(value: Any) -> str:
    text = str(value or "").strip()
    text = re.sub(r"\s+", " ", text)
    return text.strip(" ,;.-")


def _split_keywords(value: Any) -> list[str]:
    if isinstance(value, list):
        return [_clean_text(item) for item in value if _clean_text(item)]
    text = _clean_text(value)
    if not text:
        return []
    return [_clean_text(item) for item in text.split(",") if _clean_text(item)]


def _dedupe(items: list[str]) -> list[str]:
    result = []
    seen = set()
    for item in items:
        value = _clean_text(item)
        if not value:
            continue
        key = value.lower()
        if key in seen:
            continue
        seen.add(key)
        result.append(value)
    return result


def _normalize_optional_int(value: Any) -> int | None:
    text = _clean_text(value)
    if not text:
        return None
    try:
        return int(text)
    except (TypeError, ValueError):
        return None


# Составная роль: сегменты headline.
_COMPOSITE_SPLIT_RE = re.compile(r"\s*/\s*|\s*\|\s+|\s*\|\s*")

# FP&A / FPA для склейки запроса и вариантов.
_FP_A_RE = re.compile(r"fp\s*&\s*a|(?<![a-z])fpa(?![a-z])", re.I)

_QUERY_STOP_WORDS = frozenset({
    "years",
    "year",
    "experience",
    "including",
    "working",
    "over",
    "more",
    "than",
})

_FINANCE_QUERY_VARIANT_STEMS = (
    "FP&A Specialist",
    "FP&A Analyst",
    "Financial Planning and Analysis",
    "Management Reporting Analyst",
)

_COMMERCIAL_QUERY_VARIANT_STEMS = (
    "Business Development Manager",
    "Sales Director",
    "Commercial Manager",
)

_OPERATIONS_QUERY_VARIANT_STEMS = (
    "Operations Manager",
    "Chief Operating Officer",
)

_PRODUCT_QUERY_VARIANT_STEMS = (
    "Product Manager",
    "Head of Product",
)


def _word_count(text: str) -> int:
    return len([w for w in (text or "").split() if w])


def _truncate_words(text: str, max_words: int) -> str:
    words = [w for w in (text or "").split() if w]
    if not words or max_words <= 0:
        return ""
    return " ".join(words[:max_words])


def _strip_query_noise(value: str) -> str:
    """Убирает из фрагмента запроса стаж, цифры в начале, служебные слова."""
    s = _clean_text(value)
    if not s:
        return ""
    if is_resume_section_title_line(s):
        return ""
    if is_invalid_keyword_token(s):
        return ""
    out: list[str] = []
    for raw in s.split():
        w = raw.strip(" ,;.:")
        wl = w.lower()
        if not w or wl in _QUERY_STOP_WORDS:
            continue
        if re.match(r"^\d", w):
            continue
        if re.search(r"\d+\+?\s*years?", wl):
            continue
        out.append(w)
    return " ".join(out)


def _split_role_segments(role: str) -> list[str]:
    role = (role or "").strip()
    if not role:
        return []
    return [p.strip() for p in _COMPOSITE_SPLIT_RE.split(role) if p.strip()]


def _tail_has_fpa(text: str) -> bool:
    return bool(_FP_A_RE.search(text or ""))


def _merge_composite_role_for_query(segments: list[str]) -> str:
    """Склеивает составную роль в короткую поисковую строку (до max_words без локации)."""
    if not segments:
        return ""
    first = _strip_query_noise(segments[0])
    if not first:
        return ""
    if len(segments) == 1:
        return _truncate_words(first, 5)

    tail_joined = " ".join(segments[1:])
    # FP&A: первая часть + нормализованный FP&A (без «… Specialist» во primary).
    if _tail_has_fpa(tail_joined) or _tail_has_fpa(first):
        core = _truncate_words(first, 4)
        if not core:
            return ""
        return _truncate_words(f"{core} FP&A", 5)

    # Другие аббревиатуры в хвосте (B2B, SaaS, …).
    acronym_hits: list[str] = []
    for m in re.finditer(r"\b(?:[A-Z]{2,}(?:&[A-Z]+)?|FP\s*&\s*A)\b", tail_joined):
        g = m.group(0).replace(" ", "").upper()
        if g in {"FPA"} or g == "FP&A":
            if "FP&A" not in acronym_hits:
                acronym_hits.append("FP&A")
        elif len(m.group(0)) <= 8 and m.group(0) not in acronym_hits:
            acronym_hits.append(m.group(0))

    if acronym_hits:
        core = _truncate_words(first, 4)
        return _truncate_words(f"{core} {acronym_hits[0]}", 5)

    last = _strip_query_noise(segments[-1])
    lw = last.split() if last else []
    tail = " ".join(lw[-2:]) if len(lw) >= 2 else last
    core = _truncate_words(first, 3)
    if not tail:
        return core
    merged = f"{core} {tail}"
    return _strip_query_noise(_truncate_words(merged, 5))


def _finalize_query_with_location(base: str, location: str, max_total_words: int = 6) -> str:
    base = _strip_query_noise(_truncate_words(base, max_total_words))
    loc = _clean_text(location).strip()
    if not base:
        return loc if loc else ""
    if not loc:
        return base
    loc_words = loc.split()
    bw = base.split()
    room = max_total_words - len(loc_words)
    if room < 1:
        room = 1
    trimmed_base = " ".join(bw[:room])
    return f"{trimmed_base} {loc}".strip()


def _variant_with_location(role_part: str, location: str, max_words: int = 8) -> str:
    role_part = _strip_query_noise(role_part)
    if not role_part:
        return ""
    loc = _clean_text(location).strip()
    if not loc:
        return _truncate_words(role_part, max_words)
    merged = f"{role_part} {loc}".strip()
    return _truncate_words(merged, max_words)


def _build_internal_query_variants(primary_role: str, primary_query: str, location: str) -> list[str]:
    """3–5 осмысленных альтернатив поиска (роль + при необходимости локация), без мусора."""
    primary_role = (primary_role or "").strip()
    primary_query = (primary_query or "").strip().lower()
    loc = _clean_text(location).strip()
    out: list[str] = []
    seen: set[str] = {primary_query}

    def push(stem: str) -> None:
        stem = _strip_query_noise(stem)
        if not stem:
            return
        line = _variant_with_location(stem, loc)
        if not line:
            return
        lk = line.lower()
        if lk in seen:
            return
        seen.add(lk)
        out.append(line)

    if _is_finance_fpa_profile(primary_role):
        for stem in _FINANCE_QUERY_VARIANT_STEMS:
            push(stem)
    elif _is_commercial_profile(primary_role):
        for stem in _COMMERCIAL_QUERY_VARIANT_STEMS:
            push(stem)
    elif _is_operations_profile(primary_role):
        for stem in _OPERATIONS_QUERY_VARIANT_STEMS:
            push(stem)
    elif _is_product_profile(primary_role):
        for stem in _PRODUCT_QUERY_VARIANT_STEMS:
            push(stem)
    else:
        for seg in _split_role_segments(primary_role):
            seg = _strip_query_noise(seg)
            if not seg or is_resume_section_title_line(seg.lower()):
                continue
            if len(_split_role_segments(primary_role)) >= 2:
                push(seg)

    return out[:5]


class FormRecommendationAgent:
    def __init__(self, extractor: ResumeFactExtractor | None = None):
        self.extractor = extractor or ResumeFactExtractor()

    def recommend(self, resume_text: str, user_form_data: dict[str, Any] | None = None) -> FormRecommendationResult:
        user_form_data = user_form_data or {}
        facts = self.extractor.extract(resume_text or "")

        manual_position = _clean_text(user_form_data.get("position"))
        manual_industry = _clean_text(user_form_data.get("industry") or "")
        manual_location = _clean_text(user_form_data.get("location"))
        manual_email = _clean_text(user_form_data.get("email")).lower()
        manual_keywords = _split_keywords(user_form_data.get("keywords"))
        manual_employment_type = _clean_text(user_form_data.get("employment_type"))
        manual_work_format = _clean_text(user_form_data.get("work_format"))
        manual_salary_min = _normalize_optional_int(user_form_data.get("salary_min"))

        primary_role, alternative_roles, role_source = self._resolve_roles(facts, manual_position)
        industry, industry_source = self._resolve_industry(facts, primary_role, manual_industry)
        location = self._resolve_location(facts.location, facts.work_format, manual_location)
        keywords, keywords_source = self._resolve_keywords(
            resume_text, primary_role, manual_keywords, location, facts.email
        )
        query_text, query_source, query_text_variants = self._resolve_query_text(
            primary_role=primary_role,
            location=location,
            keywords=keywords,
            manual_query_text="",
        )
        email = manual_email or facts.email.lower()
        employment_type = manual_employment_type or facts.employment_type
        work_format = manual_work_format or facts.work_format
        salary_min = manual_salary_min if manual_salary_min is not None else facts.salary_min

        confidence_map = {
            "position": self._position_confidence(role_source, primary_role),
            "query_text": "high" if query_text else "low",
            "industry": "high" if manual_industry else ("medium" if industry else "low"),
            "keywords": "high" if manual_keywords else ("medium" if keywords else "low"),
            "location": "high" if manual_location else ("medium" if location else "low"),
            "email": "high" if manual_email else ("medium" if email else "low"),
            "employment_type": "high" if manual_employment_type else ("medium" if employment_type else "low"),
            "work_format": "high" if manual_work_format else ("medium" if work_format else "low"),
            "salary_min": "high" if manual_salary_min is not None else ("medium" if salary_min is not None else "low"),
            "primary_role": self._position_confidence(role_source, primary_role),
            "alternative_roles": "medium" if alternative_roles else "low",
        }

        clarification_question = self._build_clarification_question(
            primary_role=primary_role,
            alternatives=alternative_roles,
            confidence=confidence_map["position"],
            industry_hint=industry,
        )

        explanations = {
            "position": self._position_explanation(role_source, facts, manual_position),
            "query_text": self._query_explanation(query_source, query_text),
            "industry": self._industry_explanation(industry_source, industry),
            "keywords": self._keywords_explanation(keywords_source, keywords),
            "location": "Локация взята из ручного ввода пользователя." if manual_location else "Локация извлечена из контактного блока резюме." if location else "Локация не найдена.",
            "email": "E-mail взят из ручного ввода пользователя." if manual_email else "E-mail извлечён из резюме." if email else "E-mail не найден.",
            "employment_type": "Тип занятости взят из ручного ввода пользователя." if manual_employment_type else "Тип занятости извлечён из резюме." if employment_type else "Тип занятости не найден.",
            "work_format": "Формат работы взят из ручного ввода пользователя." if manual_work_format else "Формат работы извлечён из резюме." if work_format else "Формат работы не найден.",
            "salary_min": "Ожидание по доходу взято из ручного ввода пользователя." if manual_salary_min is not None else "Ожидание по доходу извлечено из резюме." if salary_min is not None else "Ожидание по доходу не найдено.",
            "primary_role": self._position_explanation(role_source, facts, manual_position),
            "alternative_roles": "Альтернативы показываются, когда роль неоднозначна или в опыте есть несколько близких позиций." if alternative_roles else "Надёжных альтернатив не найдено.",
        }

        warnings = self._build_warnings(
            manual_position=manual_position,
            manual_location=manual_location,
            manual_email=manual_email,
            manual_keywords=manual_keywords,
            primary_role=primary_role,
            location=location,
            email=email,
            keywords=keywords,
            role_source=role_source,
            resume_text=resume_text,
            facts=facts,
            position_confidence=confidence_map["position"],
        )

        return FormRecommendationResult(
            position=primary_role,
            query_text=query_text,
            query_text_variants=query_text_variants,
            keywords=keywords,
            industry=industry,
            location=location,
            email=email,
            employment_type=employment_type,
            work_format=work_format,
            salary_min=salary_min,
            primary_role=primary_role,
            alternative_roles=alternative_roles,
            clarification_question=clarification_question,
            confidence_map=confidence_map,
            explanations=explanations,
            warnings=warnings,
            extracted_facts=facts,
        )

    def _build_warnings(
        self,
        manual_position: str,
        manual_location: str,
        manual_email: str,
        manual_keywords: list[str],
        primary_role: str,
        location: str,
        email: str,
        keywords: list[str],
        role_source: str = "",
        resume_text: str = "",
        facts: Any = None,
        position_confidence: str = "low",
    ) -> list[str]:
        w: list[str] = []
        rt = (resume_text or "").lower()
        if not manual_position and not primary_role:
            w.append("Не удалось уверенно определить должность")
        elif not manual_position and primary_role and role_source == "past_roles":
            w.append("Должность взята из опыта работы; сверьте с заголовком резюме")
        elif not manual_position and primary_role and position_confidence == "low":
            w.append("Низкая уверенность в извлечённой должности")

        if not manual_email and not email:
            w.append("Не найден e-mail")
        if not manual_location and not location:
            w.append("Локация не обнаружена")
        elif not manual_location and location and position_confidence == "medium":
            w.append("Локация определена эвристически; при необходимости уточните вручную")

        if not manual_keywords and not keywords:
            w.append("Ключевые слова не выведены")
        elif not manual_keywords and len(keywords) < 3:
            w.append("Мало ключевых слов для поиска; проверьте блок навыков")

        if facts and not primary_role and rt and any(
            x in rt for x in ("summary", "professional summary", "о себе", "опыт работы")
        ):
            w.append("Текст summary/опыта найден, целевая роль не выделена — укажите должность вручную")

        return list(dict.fromkeys(w))

    def _resolve_roles(self, facts, manual_position: str) -> tuple[str, list[str], str]:
        if manual_position:
            alternatives = _dedupe([facts.desired_position, *facts.past_roles])
            alternatives.extend(ROLE_FAMILY_ALTERNATIVES.get(manual_position.lower(), []))
            alternatives = [item for item in alternatives if item.lower() != manual_position.lower()]
            return manual_position, alternatives[:3], "user"

        if facts.desired_position and is_valid_role_candidate(facts.desired_position):
            alternatives = [item for item in facts.past_roles if item.lower() != facts.desired_position.lower()]
            alternatives.extend(ROLE_FAMILY_ALTERNATIVES.get(facts.desired_position.lower(), []))
            return facts.desired_position, _dedupe(alternatives)[:3], "desired_position"

        valid_past = [r for r in facts.past_roles if is_valid_role_candidate(r)]
        if valid_past:
            primary = valid_past[0]
            alternatives = valid_past[1:4] + ROLE_FAMILY_ALTERNATIVES.get(primary.lower(), [])
            return primary, _dedupe(alternatives)[:3], "past_roles"

        return "", [], "unknown"

    def _resolve_location(self, extracted_location: str, work_format: str, manual_location: str) -> str:
        if manual_location:
            return manual_location
        if extracted_location:
            return extracted_location
        if work_format == "remote":
            return "Remote"
        return ""

    def _resolve_industry(self, facts, primary_role: str, manual_industry: str) -> tuple[str, str]:
        if manual_industry:
            return manual_industry, "user"
        if facts.primary_industry:
            return facts.primary_industry, "resume"

        role_lower = primary_role.lower()
        for industry, markers in ROLE_TO_INDUSTRY:
            if any(marker in role_lower for marker in markers):
                return industry, "role"

        return "", "unknown"

    def _resolve_query_text(
        self,
        primary_role: str,
        location: str,
        keywords: list[str],
        manual_query_text: str,
    ) -> tuple[str, str, list[str]]:
        if manual_query_text:
            mq = _strip_query_noise(manual_query_text)
            mq = _truncate_words(mq, 6)
            return mq, "user", []

        if not primary_role:
            return "", "unknown", []

        segments = _split_role_segments(primary_role)
        base = _merge_composite_role_for_query(segments)
        if not base:
            return "", "unknown", []

        # Одно релевантное ключевое слово, если запрос короткий и остаётся место по словам.
        extra = ""
        for kw in _dedupe(keywords or []):
            value = _strip_query_noise(_clean_text(kw))
            if not value or value.lower() == primary_role.lower():
                continue
            if is_invalid_keyword_token(value):
                continue
            if value.lower() in base.lower():
                continue
            extra = value
            break

        combined_base = base
        # Локация важнее доп. маркера из keywords: не раздуваем строку «роль + kw + город».
        loc_present = bool(_clean_text(location).strip())
        if extra and not loc_present and _word_count(base) <= 3:
            candidate = _strip_query_noise(f"{base} {extra}")
            candidate = _truncate_words(candidate, 5)
            if _word_count(candidate) <= 5:
                combined_base = candidate

        query_final = _finalize_query_with_location(combined_base, location, max_total_words=6)
        variants = _build_internal_query_variants(primary_role, query_final, location)

        return query_final, "inferred", variants

    def _strip_location_email_from_keywords(
        self, keywords: list[str], location: str, extracted_email: str
    ) -> list[str]:
        loc = _clean_text(location).strip().lower()
        em = _clean_text(extracted_email).strip().lower()
        out: list[str] = []
        for k in keywords:
            ck = _clean_text(k)
            if not ck:
                continue
            kl = ck.lower()
            if "@" in ck or re.search(r"\+?\d[\d\s\-()]{8,}", ck):
                continue
            if re.search(r"linkedin\.com|http|www\.", kl):
                continue
            if em and em == kl:
                continue
            if loc and kl == loc:
                continue
            if loc and len(loc) > 3 and loc in kl and len(ck.split()) <= 4:
                continue
            out.append(ck)
        return out

    def _resolve_keywords(
        self,
        resume_text: str,
        primary_role: str,
        manual_keywords: list[str],
        location: str = "",
        extracted_email: str = "",
    ) -> tuple[list[str], str]:
        if manual_keywords:
            return _dedupe(manual_keywords)[:6], "user"

        sections = split_resume_sections(resume_text or "")
        weighted_hits = []
        # Сначала навыки и опыт — не тянуть маркеры из всего текста (там заголовки секций и summary).
        search_spaces = [
            (sections.get("skills", "").lower(), 4),
            (sections.get("experience", "").lower(), 3),
            (sections.get("target", "").lower(), 2),
            (sections.get("summary", "").lower(), 1),
        ]

        for marker, base_weight in KEYWORD_MARKERS:
            score = 0
            for block, bonus in search_spaces:
                if marker.lower() in block:
                    score += base_weight + bonus
            if score > 0:
                weighted_hits.append((score, marker))

        full_lower = (resume_text or "").lower()
        if len(weighted_hits) < 6:
            already = {m for _, m in weighted_hits}
            for marker, base_weight in KEYWORD_MARKERS:
                if marker in already:
                    continue
                if marker.lower() in full_lower:
                    weighted_hits.append((base_weight + 1, marker))

        weighted_hits.sort(key=lambda item: (-item[0], item[1]))
        ordered_keywords = _dedupe(
            [marker for _score, marker in weighted_hits if not is_invalid_keyword_token(marker)]
        )

        specific_keywords = [item for item in ordered_keywords if item.lower() not in GENERIC_KEYWORDS]
        generic_keywords = [item for item in ordered_keywords if item.lower() in GENERIC_KEYWORDS]

        facts = self.extractor.extract(resume_text or "")
        fact_keywords: list[str] = []
        for item in facts.competencies:
            value = _clean_text(item)
            if not value or value.lower() in GENERIC_KEYWORDS:
                continue
            if is_invalid_keyword_token(value):
                continue
            fact_keywords.append(value)

        selected = [k for k in specific_keywords[:6] if not is_invalid_keyword_token(k)]
        if len(selected) < 4:
            for item in fact_keywords:
                if item.lower() not in {keyword.lower() for keyword in selected}:
                    selected.append(item)
                if len(selected) >= 6:
                    break
        if len(selected) < 4:
            selected.extend(
                k
                for k in generic_keywords[: max(0, 6 - len(selected))]
                if not is_invalid_keyword_token(k)
            )

        selected = _dedupe([k for k in selected if not is_invalid_keyword_token(k)])
        low = (resume_text or "").lower()
        compact = low.replace(" ", "")
        if _is_finance_fpa_profile(primary_role):
            # Сначала профессиональные маркеры из текста (в т.ч. Excel / VBA из навыков), затем остальное.
            finance_first: list[str] = []
            for seed in FINANCE_KEYWORD_SEEDS:
                seed_l = seed.lower()
                if seed_l in low or seed_l.replace(" ", "") in compact:
                    if seed not in finance_first:
                        finance_first.append(seed)
            merged: list[str] = []
            seen_m: set[str] = set()
            for item in finance_first + selected:
                lk = item.lower()
                if lk in seen_m:
                    continue
                seen_m.add(lk)
                merged.append(item)
            selected = merged

        selected = self._strip_location_email_from_keywords(
            _dedupe(selected), location, extracted_email or (facts.email or "")
        )
        return _dedupe(selected)[:12], ("inferred" if selected else "unknown")

    def _position_confidence(self, source: str, value: str) -> str:
        if not value:
            return "low"
        if source in {"user", "desired_position"}:
            return "high"
        if source == "past_roles":
            return "medium"
        return "low"

    def _build_clarification_question(
        self,
        primary_role: str,
        alternatives: list[str],
        confidence: str,
        industry_hint: str,
    ) -> str:
        if not primary_role and alternatives:
            return f"Какую роль считать основной для поиска: {', '.join(alternatives[:3])}?"
        if confidence != "high" and len(alternatives) >= 2:
            return (
                f"Какую роль считать основной для поиска: «{primary_role}» "
                f"или один из вариантов: {', '.join(alternatives[:3])}?"
            )
        if not primary_role:
            return "Какую должность вы хотите искать в первую очередь?"
        if not industry_hint:
            return "В какой отрасли искать вакансии в первую очередь?"
        return ""

    def _position_explanation(self, source: str, facts, manual_position: str) -> str:
        if source == "user":
            return "Использовано ручное значение пользователя; агент не подменяет его своей гипотезой."
        if source == "desired_position":
            return "В резюме найдена явно указанная желаемая должность, поэтому она важнее прошлых ролей."
        if source == "past_roles":
            return "Явная желаемая должность не найдена, поэтому агент осторожно использует последнюю релевантную роль из опыта."
        if manual_position:
            return "Использовано ручное значение пользователя."
        return "Надёжная роль не определена."

    def _industry_explanation(self, source: str, industry: str) -> str:
        if source == "user":
            return "Сфера поиска взята из ручного ввода пользователя."
        if source == "resume":
            return f"Сфера поиска определена по резюме: «{industry}»."
        if source == "role":
            return f"Сфера поиска осторожно выведена из целевой роли: «{industry}»."
        return "Надёжная сфера поиска пока не определена."

    def _query_explanation(self, source: str, query_text: str) -> str:
        if source == "user":
            return "Поисковый запрос взят из ручного ввода пользователя."
        if source == "inferred":
            return f"Поисковый запрос собран из целевой роли (включая короткую склейку для составных заголовков) и локации: «{query_text}»."
        return "Надёжный поисковый запрос пока не определён."

    def _keywords_explanation(self, source: str, keywords: list[str]) -> str:
        if source == "user":
            return "Ключевые слова сохранены из ручного ввода пользователя."
        if source == "inferred" and keywords:
            return "Ключевые слова собраны по явным маркерам из резюме без агрессивного додумывания."
        return "Ключевых слов недостаточно для уверенной рекомендации."
