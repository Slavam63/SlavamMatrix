from __future__ import annotations

import re

from app.resume_form_mapper import (
    _detect_industry,
    _extract_email,
    _extract_employment_type,
    _extract_location,
    _extract_position_from_target_section,
    _extract_salary,
    _extract_work_format,
    _normalize_industry_label,
    is_invalid_keyword_token,
    is_resume_section_title_line,
    is_valid_role_candidate,
    split_resume_sections,
)

from .schemas import ResumeFacts


PHONE_PATTERN = re.compile(r"(?:(?:\+7|8)[\d\s()\-]{9,}\d)")
ROLE_HINTS = (
    "директор",
    "руководител",
    "менеджер",
    "manager",
    "head",
    "chief",
    "lead",
    "developer",
    "engineer",
    "architect",
    "analyst",
    "consultant",
    "owner",
)
ROLE_BLACKLIST = (
    "ооо",
    "ао ",
    "пао",
    "llc",
    "inc",
    "образование",
    "навыки",
    "skills",
    "summary",
    "email",
    "телефон",
)
DATE_MARKER = re.compile(
    r"(?:19|20)\d{2}\s*[-–]\s*(?:19|20)\d{2}|(?:19|20)\d{2}\s*[-–]\s*(?:н\.?\s*в\.?|present)|\b\d{2}\.\d{4}\b",
    flags=re.I,
)

CEFR_LEVEL_RE = re.compile(r"\b(?:A1|A2|B1|B2|C1|C2)\b", flags=re.I)

SECTION_SUBSTRINGS = (
    "дополнительная информация",
    "рекомендации",
    "о себе",
    "образование",
    "навыки",
    "ключевые навыки",
    "языки",
    "контакты",
    "опыт работы",
    "summary",
    "skills",
)

LANGUAGE_SUBSTRINGS = ("английский", "русский", "english", "russian")

PROFICIENCY_SUBSTRINGS = (
    "родной",
    "native",
    "intermediate",
    "upper-intermediate",
    "upper",
    "advanced",
)

_COMPANY_LATIN_RE = re.compile(
    r"\b(?:llc|l\.l\.c\.|inc|ltd|limited|corp\.?|corporation|group)\b",
    flags=re.I,
)
_COMPANY_RU_RE = re.compile(r"\b(?:ооо|оао|зао|ао|пао|ип)\b", flags=re.I)

JUNK_WORD_SUBSTRINGS = ("информация", "рекомендации", "контакты")

PAREN_ROLE_SUBSTRING_RE = re.compile(
    r"\([^)]*(?:финансовый|директор|правлен|менеджер|chief|ceo|cio|cto|cfo|coo)[^)]*\)",
    flags=re.I,
)

# Фразы из 2–3 «именных» по регистру слов, которые не являются ФИО (частые компетенции).
NOT_A_NAME_PHRASES = {
    "цифровая трансформация",
    "стратегия ит",
    "информационная безопасность",
    "управление проектами",
    "управление командой",
    "операционная эффективность",
    "стратегическое планирование",
    "развитие бизнеса",
}


def _clean_text(value: str) -> str:
    text = str(value or "").replace("\r", "\n").strip()
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip(" \n\r\t,;.-")


def _dedupe(items: list[str]) -> list[str]:
    result = []
    seen = set()
    for item in items:
        value = _clean_text(item)
        if not value:
            continue
        key = value.lower()
        if key in seen:
            continue
        seen.add(key)
        result.append(value)
    return result


def _collapse_ws(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip())


def _normalize_competency_token(value: str) -> str:
    text = str(value or "").replace("\r", "\n")
    text = text.strip(" \t\n\r\"'“”«»•·●◦▪▫-–—:;,.")
    text = re.sub(r"^[•\-–—]+\s*", "", text)
    return _collapse_ws(text)


def _normalize_role_for_match(role: str) -> str:
    text = _collapse_ws(role).lower()
    text = text.strip(" .,:;—–-/")
    return text


def _looks_like_title_case_person_line(value: str, lower_value: str) -> bool:
    words = value.split()
    if not (2 <= len(words) <= 3):
        return False

    phrase = " ".join(w.lower() for w in words)
    if phrase in NOT_A_NAME_PHRASES:
        return False

    if any(len(w) > 14 for w in words):
        return False

    if any(ch.isdigit() for ch in value) or "/" in value or "\\" in value:
        return False

    latin_word = re.compile(r"^[A-Z][a-z]{1,24}$")
    cyrillic_word = re.compile(r"^[А-ЯЁ][а-яё]{1,24}$")

    for w in words:
        if re.fullmatch(r"[A-Z]{2,6}", w):
            return False
        if not (latin_word.match(w) or cyrillic_word.match(w)):
            return False

    if len(words) == 2 and all(cyrillic_word.match(w) for w in words):
        return True

    if len(words) >= 2 and all(latin_word.match(w) for w in words):
        return True

    return False


def _should_drop_competency(value: str, role_norm: str) -> bool:
    if not value:
        return True

    lower_value = value.lower()

    if len(value) > 60:
        return True

    if value.count(",") > 2:
        return True

    if CEFR_LEVEL_RE.search(value):
        return True

    for marker in LANGUAGE_SUBSTRINGS:
        if marker in lower_value:
            return True

    for marker in PROFICIENCY_SUBSTRINGS:
        if marker in lower_value:
            return True

    for marker in SECTION_SUBSTRINGS:
        if marker in lower_value:
            return True

    if _COMPANY_LATIN_RE.search(lower_value) or _COMPANY_RU_RE.search(lower_value):
        return True

    for marker in JUNK_WORD_SUBSTRINGS:
        if marker in lower_value:
            return True

    if PAREN_ROLE_SUBSTRING_RE.search(value):
        return True

    stripped = value.strip()
    if stripped.startswith("(") and stripped.endswith(")"):
        return True

    if _looks_like_title_case_person_line(value, lower_value):
        return True

    if PHONE_PATTERN.search(value):
        return True

    if re.search(r"https?://", lower_value) or "@" in value:
        return True

    if role_norm and len(role_norm) >= 4 and role_norm in lower_value:
        return True

    return False


def _extract_competencies(sections: dict[str, str], desired_position: str) -> list[str]:
    source = "\n".join([
        sections.get("skills", ""),
        sections.get("target", ""),
        sections.get("summary", ""),
    ])
    role_norm = _normalize_role_for_match(desired_position)

    raw_items = re.split(r"[,;\n|/•·–—:]+", source)
    out: list[str] = []
    seen: set[str] = set()

    for item in raw_items:
        value = _normalize_competency_token(item)
        if len(value) < 2:
            continue
        if is_invalid_keyword_token(value):
            continue
        if _should_drop_competency(value, role_norm):
            continue
        normalized = value.lower()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        out.append(normalized)
        if len(out) >= 8:
            break

    return out


class ResumeFactExtractor:
    def extract(self, resume_text: str) -> ResumeFacts:
        clean_text = _clean_text(resume_text)
        sections = split_resume_sections(clean_text)

        contacts_source = "\n".join([sections.get("contacts", ""), clean_text[:1200]])
        target_source = sections.get("target", "")
        summary_source = sections.get("summary", "")
        top_source = "\n".join([target_source, summary_source, clean_text[:1500]])

        industry = _normalize_industry_label(_detect_industry(sections))
        salary_raw = _extract_salary(target_source or clean_text[:1200])
        try:
            salary_min = int(salary_raw) if salary_raw else None
        except ValueError:
            salary_min = None

        location = _extract_location(contacts_source)
        work_format = _extract_work_format(target_source or clean_text[:1200])
        if not location and work_format == "remote":
            location = "Remote"

        primary_industry = industry if industry and industry != "Другое" else ""

        desired_position = _extract_position_from_target_section(
            target_source, top_source, summary_source, clean_text
        )

        return ResumeFacts(
            email=_extract_email(contacts_source),
            phone=self._extract_phone(contacts_source),
            location=location,
            desired_position=desired_position,
            past_roles=self._extract_past_roles(sections.get("experience", "")),
            competencies=_extract_competencies(sections, desired_position),
            primary_industry=primary_industry,
            industry_candidates=[primary_industry] if primary_industry else [],
            employment_type=_extract_employment_type(target_source or clean_text[:1200]),
            work_format=work_format,
            salary_min=salary_min,
        )

    def _extract_phone(self, text: str) -> str:
        match = PHONE_PATTERN.search(text or "")
        if not match:
            return ""
        return _clean_text(match.group(0))

    def _extract_past_roles(self, experience_text: str) -> list[str]:
        lines = [line.strip() for line in (experience_text or "").splitlines() if line.strip()]
        candidates = []

        for index, line in enumerate(lines):
            lower_line = line.lower()
            if len(line) < 4 or len(line) > 120:
                continue
            if is_resume_section_title_line(line):
                continue
            if not is_valid_role_candidate(line):
                continue
            if any(marker in lower_line for marker in ROLE_BLACKLIST):
                continue
            if not any(marker in lower_line for marker in ROLE_HINTS):
                continue

            prev_line = lines[index - 1] if index > 0 else ""
            next_line = lines[index + 1] if index + 1 < len(lines) else ""
            if DATE_MARKER.search(prev_line) or DATE_MARKER.search(next_line) or DATE_MARKER.search(line):
                candidates.append(line)

        return _dedupe(candidates)[:5]
