import html
import re


SECTION_HEADERS = {
    "target": [
        "желаемая должность",
        "желаемая должность и зарплата",
        "position",
        "objective",
        "цель",
        "должность",
    ],
    "summary": [
        "о себе",
        "обо мне",
        "summary",
        "professional summary",
        "profile",
        "about me",
        "career objective",
        "общие сведения",
    ],
    "experience": [
        "опыт работы",
        "experience",
    ],
    "education": [
        "образование",
        "education",
    ],
    "skills": [
        "навыки",
        "key skills",
        "skills",
        "core competencies",
        "technical skills",
        "профессиональные навыки",
    ],
    "contacts": [
        "проживает",
        "гражданство",
        "готова к переезду",
        "готов к переезду",
        "location",
        "email",
        "e-mail",
        "телефон",
    ],
}


INLINE_SECTION_BREAKS = [
    "Цель",
    "Должность",
    "Общие сведения",
    "Опыт работы",
    "Профессиональные навыки",
    "Навыки",
    "Образование",
    "Тренинги, сертификаты",
    "Проекты",
    "О себе",
    "Обо мне",
    "Professional Summary",
    "Work Experience",
    "Education",
    "Skills",
    "Core Competencies",
    "Contact",
]


INDUSTRY_CHOICES = [
    "Финансы",
    "Управление персоналом",
    "Продажи / Развитие бизнеса",
    "Маркетинг / PR / Бренд",
    "Операционное управление",
    "Логистика / Закупки / Supply Chain",
    "Производство / Инжиниринг",
    "Проектное управление",
    "IT / Digital / Product",
    "Юриспруденция / Compliance",
    "Туризм / Гостеприимство",
    "HoReCa / Ресторанный бизнес",
    "Гостиничный бизнес",
    "FMCG / Retail / Пищевая отрасль",
    "Энергетика / Нефтегаз",
    "Медицина / Фарма",
    "Строительство / Девелопмент / Недвижимость",
    "Образование",
    "Государственный сектор",
    "Консалтинг",
    "Другое",
]

INDUSTRY_DEFAULT = "Другое"
INDUSTRY_SET = set(INDUSTRY_CHOICES)
INDUSTRY_ORDER = {name: idx for idx, name in enumerate(INDUSTRY_CHOICES)}
INDUSTRY_CANON_BY_LOWER = {item.lower(): item for item in INDUSTRY_CHOICES}


INDUSTRY_ALIASES = {
    "финансы": "Финансы",
    "finance": "Финансы",
    "financial": "Финансы",
    "управление персоналом": "Управление персоналом",
    "hr": "Управление персоналом",
    "human resources": "Управление персоналом",
    "talent acquisition": "Управление персоналом",
    "продажи": "Продажи / Развитие бизнеса",
    "sales": "Продажи / Развитие бизнеса",
    "развитие бизнеса": "Продажи / Развитие бизнеса",
    "business development": "Продажи / Развитие бизнеса",
    "маркетинг": "Маркетинг / PR / Бренд",
    "marketing": "Маркетинг / PR / Бренд",
    "бренд": "Маркетинг / PR / Бренд",
    "brand": "Маркетинг / PR / Бренд",
    "pr": "Маркетинг / PR / Бренд",
    "операционное управление": "Операционное управление",
    "operations": "Операционное управление",
    "логистика": "Логистика / Закупки / Supply Chain",
    "закупки": "Логистика / Закупки / Supply Chain",
    "supply chain": "Логистика / Закупки / Supply Chain",
    "scm": "Логистика / Закупки / Supply Chain",
    "производство": "Производство / Инжиниринг",
    "инжиниринг": "Производство / Инжиниринг",
    "engineering": "Производство / Инжиниринг",
    "project management": "Проектное управление",
    "управление проектами": "Проектное управление",
    "проектное управление": "Проектное управление",
    "it": "IT / Digital / Product",
    "digital": "IT / Digital / Product",
    "product": "IT / Digital / Product",
    "юриспруденция": "Юриспруденция / Compliance",
    "legal": "Юриспруденция / Compliance",
    "compliance": "Юриспруденция / Compliance",
    "туризм": "Туризм / Гостеприимство",
    "travel": "Туризм / Гостеприимство",
    "гостеприимство": "Туризм / Гостеприимство",
    "hospitality": "Туризм / Гостеприимство",
    "horeca": "HoReCa / Ресторанный бизнес",
    "ресторанный бизнес": "HoReCa / Ресторанный бизнес",
    "ресторан": "HoReCa / Ресторанный бизнес",
    "гостиничный бизнес": "Гостиничный бизнес",
    "hotel": "Гостиничный бизнес",
    "fmcg": "FMCG / Retail / Пищевая отрасль",
    "retail": "FMCG / Retail / Пищевая отрасль",
    "пищевая отрасль": "FMCG / Retail / Пищевая отрасль",
    "энергетика": "Энергетика / Нефтегаз",
    "нефтегаз": "Энергетика / Нефтегаз",
    "oil & gas": "Энергетика / Нефтегаз",
    "медицина": "Медицина / Фарма",
    "фарма": "Медицина / Фарма",
    "healthcare": "Медицина / Фарма",
    "строительство": "Строительство / Девелопмент / Недвижимость",
    "девелопмент": "Строительство / Девелопмент / Недвижимость",
    "недвижимость": "Строительство / Девелопмент / Недвижимость",
    "real estate": "Строительство / Девелопмент / Недвижимость",
    "образование": "Образование",
    "education": "Образование",
    "государственный сектор": "Государственный сектор",
    "госслужба": "Государственный сектор",
    "госуправление": "Государственный сектор",
    "консалтинг": "Консалтинг",
    "consulting": "Консалтинг",
    "advisory": "Консалтинг",
    "другое": "Другое",
}


INDUSTRY_RULES = [
    (
        r"\b(cfo|finance director|head of finance|финанс(ы|овый|ов)?|казначейств|бюджетирован|ifrs|gaap|fp&a|controlling|управленческ(ий|ая) учет|финансов(ый|ого)? анализ)\b",
        "Финансы",
    ),
    (
        r"\b(hr|hrd|human resources|talent acquisition|recruit(ment)?|подбор персонала|обучение персонала|организационн(ое|ая) развитие|компенсаци[яи]|льготы|c&b)\b",
        "Управление персоналом",
    ),
    (
        r"\b(sales|b2b|b2c|коммерческ(ий|ая) директор|директор по продажам|продаж[аи]|business development|развитие бизнеса|key account|аккаунт)\b",
        "Продажи / Развитие бизнеса",
    ),
    (
        r"\b(marketing|бренд|brand|digital marketing|performance marketing|маркетинг|pr\b|пиар|communications?)\b",
        "Маркетинг / PR / Бренд",
    ),
    (
        r"\b(operations?|операционн(ый|ое) директор|операционное управление|coo\b|process improvement|lean|бережлив(ое|ого)? производств|оптимизац(ия|ии) процессов|директор по сервису|руководител[ья] сервиса|customer service|service operations|service excellence|послепродажн(ый|ого) сервис|after[- ]sales service|сервисн(ый|ого) центр)\b",
        "Операционное управление",
    ),
    (
        r"\b(logistics|supply chain|supply-chain|scm\b|логистик|склад|транспорт|закупк|procurement|цепочк[аи] поставок|цепочками поставок|управление цепочками поставок|поставк[аи])\b",
        "Логистика / Закупки / Supply Chain",
    ),
    (
        r"\b(production|manufacturing|завод|предприятие|производств|главный инженер|technical director|engineering)\b",
        "Производство / Инжиниринг",
    ),
    (
        r"\b(project manager|program manager|руководител[ья] проектов|управление проектами|project management|pmo\b|scrum master|agile coach)\b",
        "Проектное управление",
    ),
    (
        r"\b(product manager|product owner|product director|it director|cto\b|cio\b|software|developer|разработчик|программист|devops|qa engineer|data scientist|machine learning|ml engineer|ai\b|llm\b|erp\b|crm\b|1с\b|sap\b|oracle\b|tableau\b|power bi)\b",
        "IT / Digital / Product",
    ),
    (
        r"\b(legal|юрист|правов(ое|ая|ой)|compliance|комплаенс|договорн(ая|ое) работа|регуляторик)\b",
        "Юриспруденция / Compliance",
    ),
    (
        r"\b(туризм|travel|travel management|туроператор|турагент|гостеприимств|hospitality)\b",
        "Туризм / Гостеприимство",
    ),
    (
        r"\b(horeca|ресторан|кафе|bar|bartender|chef|шеф|f&b|food service|общественн(ое|ого) питани)\b",
        "HoReCa / Ресторанный бизнес",
    ),
    (
        r"\b(гостиниц|отел(ь|и)|hotel manager|hotel operations|front office|reception)\b",
        "Гостиничный бизнес",
    ),
    (
        r"\b(fmcg|retail|ритейл|мерчандайзинг|категорийн(ый|ого) менеджер|продукты питания|пищев(ая|ой) отрасл|e-commerce)\b",
        "FMCG / Retail / Пищевая отрасль",
    ),
    (
        r"\b(энергетик|электроэнерг|генерац|теплоэнерг|нефтегаз|нефть|газ|добыч|upstream|downstream)\b",
        "Энергетика / Нефтегаз",
    ),
    (
        r"\b(pharma|фарма|медицин|healthcare|здравоохранен|clinical|gxp|gmp)\b",
        "Медицина / Фарма",
    ),
    (
        r"\b(construction|девелопмент|строительств|недвижимост|real estate|технадзор|проектировани[ея])\b",
        "Строительство / Девелопмент / Недвижимость",
    ),
    (
        r"\b(образовани|преподавател|учител|методист|декан|академическ|университет|школа|edtech|e-learning)\b",
        "Образование",
    ),
    (
        r"\b(государственн(ый|ого)? сектор|госслужб|гос управлен|госуправлен|муниципальн|министерств|ведомств|госзакупк|администраци[яи])\b",
        "Государственный сектор",
    ),
    (
        r"\b(консалтинг|consulting|strategy consulting|management consulting|advisory|big4|big 4)\b",
        "Консалтинг",
    ),
]


GENERIC_KEYWORD_MARKERS = [
    "управление командой",
    "руководство командой",
    "стратегическое планирование",
    "бюджетирование",
    "управление проектами",
    "переговоры",
    "развитие бизнеса",
    "оптимизация процессов",
    "kpi",
    "аналитика",
    "отчетность",
    "клиентский опыт",
    "process improvement",
    "risk management",
]


ROLE_STOP_MARKERS = [
    "занятость",
    "график",
    "опыт работы",
    "experience",
    "навыки",
    "skills",
    "ключевые результаты",
    "обо мне",
    "о себе",
    "общие сведения",
    "образование",
    "education",
    "гражданство",
    "проживает",
    "готова к переезду",
    "готов к переезду",
    "professional summary",
    "core competencies",
    "key skills",
    "employment history",
    "work experience",
]


# Заголовки секций резюме (EN/RU) — не являются названием должности.
RESUME_SECTION_TITLE_EXACT = {
    "professional summary",
    "summary",
    "profile",
    "about",
    "about me",
    "personal profile",
    "career objective",
    "career summary",
    "executive summary",
    "overview",
    "core competencies",
    "key competencies",
    "key skills",
    "key skills & competencies",
    "technical skills",
    "skills",
    "professional experience",
    "experience",
    "work experience",
    "employment history",
    "work history",
    "education",
    "academic background",
    "certifications",
    "certification",
    "licenses",
    "recommendations",
    "references",
    "languages",
    "awards",
    "projects",
    "publications",
    "hobbies",
    "interests",
    "обо мне",
    "о себе",
    "общие сведения",
    "ключевые навыки",
    "профессиональные навыки",
    "опыт работы",
    "образование",
    "контакты",
    "контактная информация",
    "contact",
    "contacts",
    "contact details",
    "contact information",
    "personal information",
    "objective",
    "дополнительная информация",
}

# Первые слова строки совпадают с типичным заголовком секции (даже с номером/буллетом).
RESUME_SECTION_TITLE_PREFIX_RE = re.compile(
    r"^(?:[\d\.\)\-–—]+\s*)?"
    r"(?:"
    r"professional\s+summary|executive\s+summary|career\s+(?:objective|summary)|"
    r"personal\s+(?:profile|information|statement)|\babout\s+me\b|"
    r"key\s+(?:skills|competencies|achievements|qualifications)|"
    r"core\s+competencies|technical\s+skills|soft\s+skills|"
    r"work\s+(?:experience|history)|professional\s+experience|employment\s+history|"
    r"education(?:al)?\s+background|academic\s+background|"
    r"certifications?|licenses|references|languages|awards|projects|publications|"
    r"contact\s+(?:details|information)|"
    r"обо\s+мне|о\s+себе|опыт\s+работы|образование|навыки|контакты|рекомендации|"
    r"ключевые\s+компетенции|профессиональный\s+опыт|карьерные\s+цели|"
    r"дополнительные\s+сведения|языки"
    r")\b",
    flags=re.I,
)


def _normalize_section_heading_line(value: str) -> str:
    s = (value or "").strip()
    s = s.strip(":-–—•·●◦▪▫").strip()
    s = re.sub(r"^[\d\.\)\-–—]+\s*", "", s)
    return re.sub(r"\s+", " ", s).lower()


def _is_resume_section_title_line(lower_line: str) -> bool:
    s = _normalize_section_heading_line(lower_line)
    if not s:
        return True
    if s in RESUME_SECTION_TITLE_EXACT:
        return True
    if s.rstrip(":") in RESUME_SECTION_TITLE_EXACT:
        return True
    if s in {"summary", "profile", "education", "experience", "skills", "references", "about"}:
        return True
    # «Professional Summary — text» или заголовок с двоеточием
    first = s.split(":", maxsplit=1)[0].strip()
    if first in RESUME_SECTION_TITLE_EXACT:
        return True
    if RESUME_SECTION_TITLE_PREFIX_RE.match(lower_line.strip()):
        return True
    return False


def is_resume_section_title_line(value: str) -> bool:
    """Публичная проверка: строка — заголовок секции резюме (не должность)."""
    return _is_resume_section_title_line((value or "").lower())


_HEADLINE_ROLE_PATTERN = re.compile(
    r"\b(analyst|specialist|manager|director|lead|head|chief|officer|consultant|engineer|developer|"
    r"coordinator|controller|fp&a|fpa|fp\s*&\s*a|finance|financial|accounting|бухгалтер|аналитик|"
    r"директор|специалист|руководител|менеджер|executive|associate|vp\b|vice\s+president|partner|"
    r"cfo|cto|cio|coo|ceo)\b",
    flags=re.I,
)

# Минимум одно «слово должности» (EN/RU), иначе это не заголовок роли.
_ROLE_WORD_CORE_RE = re.compile(
    r"\b(analyst|specialist|manager|director|lead|head|chief|officer|consultant|engineer|developer|"
    r"coordinator|controller|fp&a|fpa|finance|financial|accounting|директор|специалист|руководител|менеджер|"
    r"аналитик|executive|associate|partner|cfo|cto|cio|coo|ceo|vp\b|vice\s+president|начальник|заместител)\b",
    flags=re.I,
)


ROLE_JUNK_MARKERS = [
    "hyperlink",
    "&quot",
    "quot;",
    "&amp",
    "amp;",
    "xml",
    "http",
    "https",
]


ROLE_HEADER_ONLY = {
    "цель",
    "должность",
    "желаемая должность",
    "position",
    "objective",
}

ROLE_INVALID_EXACT = {
    "и зарплата",
    "зарплата",
    "и заработная плата",
    "заработная плата",
}


KEYWORD_STOP_WORDS = {
    "цель",
    "должность",
    "желаемая должность",
    "position",
    "objective",
    "общие сведения",
}


ROLE_CASE_RULES = [
    (r"\bруководителя\b", "Руководитель"),
    (r"\bдиректора\b", "Директор"),
    (r"\bначальника\b", "Начальник"),
    (r"\bменеджера\b", "Менеджер"),
    (r"\bконсультанта\b", "Консультант"),
    (r"\bаналитика\b", "Аналитик"),
    (r"\bархитектора\b", "Архитектор"),
    (r"\bразработчика\b", "Разработчик"),
    (r"\bспециалиста\b", "Специалист"),
]


ROLE_PRIORITY_PATTERNS = [
    r"\bгенеральный директор\b",
    r"\bисполнительный директор\b",
    r"\bоперационный директор\b",
    r"\bкоммерческий директор\b",
    r"\bфинансовый директор\b",
    r"\bтехнический директор\b",
    r"\bдиректор по\b",
    r"\bруководитель\b",
    r"\bhead of\b",
    r"\bchief\b",
    r"\bdirector\b",
    r"\bmanager\b",
]


def _preclean_text(text):
    text = html.unescape(text or "")
    text = text.replace("\xa0", " ")
    text = text.replace("\ufeff", " ")
    text = text.replace("ё", "е")

    replacements = [
        ("HYPERLINK", " "),
        ("hyperlink", " "),
        ("&quot;", " "),
        ("quot;", " "),
        ("&amp;", " "),
        ("amp;", " "),
        ("&#34;", " "),
        ("&#39;", " "),
    ]
    for old, new in replacements:
        text = text.replace(old, new)

    text = re.sub(r"https?://\S+", " ", text, flags=re.I)
    text = re.sub(r"www\.\S+", " ", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    return text


def _inject_inline_section_breaks(text):
    text = text or ""
    for marker in INLINE_SECTION_BREAKS:
        text = re.sub(rf"\s+({re.escape(marker)})\s+", rf"\n\1 ", text, flags=re.I)
    return text


def _clean_text(text):
    text = _preclean_text(text)
    text = _inject_inline_section_breaks(text)
    text = text.replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"[ ]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _clean_value(value, max_len=255):
    value = _preclean_text(value)
    value = " ".join((value or "").split()).strip(" ,;.-")
    if len(value) > max_len:
        value = value[:max_len].rstrip(" ,;.-")
    return value


def _split_lines(text):
    return [line.strip() for line in text.splitlines() if line.strip()]


def _find_section_indices(lines):
    found = []

    for idx, line in enumerate(lines):
        lower_line = line.lower()
        for section_name, markers in SECTION_HEADERS.items():
            if any(marker in lower_line for marker in markers):
                found.append((idx, section_name))
                break

    unique = []
    used = set()
    for idx, section_name in found:
        key = (idx, section_name)
        if key not in used:
            used.add(key)
            unique.append((idx, section_name))

    unique.sort(key=lambda item: item[0])
    return unique


def split_resume_sections(text):
    text = _clean_text(text)
    lines = _split_lines(text)

    sections = {
        "raw_text": text,
        "contacts": "",
        "target": "",
        "summary": "",
        "experience": "",
        "education": "",
        "skills": "",
    }

    if not lines:
        return sections

    indices = _find_section_indices(lines)

    if indices:
        for pos, (start_idx, section_name) in enumerate(indices):
            end_idx = len(lines)
            if pos + 1 < len(indices):
                end_idx = indices[pos + 1][0]

            block = "\n".join(lines[start_idx:end_idx]).strip()
            if block and not sections.get(section_name):
                sections[section_name] = block

    top_chunk = "\n".join(lines[:8]).strip()
    if not sections["contacts"]:
        sections["contacts"] = top_chunk

    if not sections["target"]:
        match = re.search(
            r"(?:\bцель\b\s*)?(?:\bдолжность\b\s+)(.+?)(?=\bобщие сведения\b|\bо себе\b|\bопыт работы\b|\bнавыки\b|\bпрофессиональные навыки\b|$)",
            text,
            flags=re.I | re.S,
        )
        if match:
            sections["target"] = _clean_value(match.group(1), 300)

    return sections


def _extract_email(text):
    matches = re.findall(r"[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}", text or "", flags=re.I)
    if not matches:
        return ""

    cleaned = []
    for item in matches:
        value = item.strip().lower()
        local = value.split("@", 1)[0]
        if value.startswith("."):
            continue
        if len(local.replace(".", "").replace("-", "").replace("_", "")) < 3:
            continue
        cleaned.append(value)

    if cleaned:
        return cleaned[-1]

    return matches[-1].strip().lower()


def _extract_location(text):
    match = re.search(r"проживает\s*:\s*([^\n]{2,80})", text or "", flags=re.I)
    if match:
        return _clean_value(match.group(1), 80)

    fallback = re.search(
        r"\b(Москва|Санкт-Петербург|Петербург|Казань|Екатеринбург|Новосибирск|Краснодар|Нижний Новгород|Самара|Ростов-на-Дону|Калининград|Минск|Алматы|Ташкент|Тбилиси|Dubai|Abu Dhabi|Berlin|Frankfurt|Munich|Remote)\b",
        text or "",
        flags=re.I,
    )
    return fallback.group(1) if fallback else ""


def _trim_role_noise(value):
    value = _clean_value(value, 300)
    if not value:
        return ""

    value = re.sub(r"^[\d\-\s]{4,}", "", value).strip(" ,;.-")
    value = re.sub(r"\bHYPERLINK\b.*$", "", value, flags=re.I)
    value = re.sub(r"&quot.*$", "", value, flags=re.I)
    value = re.sub(r"\bquot;.*$", "", value, flags=re.I)
    value = re.sub(r"^(?:цель|должность|желаемая должность)\b[:\s\-]*", "", value, flags=re.I).strip(" ,;.-")
    value = re.sub(r"^(?:и\s+)?зарплат[аы]\b[:\s\-]*", "", value, flags=re.I).strip(" ,;.-")
    value = re.sub(r"^и\s+заработн(?:ая|ой)\s+плат(?:а|ы)\b[:\s\-]*", "", value, flags=re.I).strip(" ,;.-")

    lowered = value.lower()
    for marker in ROLE_STOP_MARKERS:
        idx = lowered.find(marker)
        if idx > 0:
            value = value[:idx].strip(" ,;.-")
            lowered = value.lower()

    value = re.split(
        r"\b(?:Занятость|График|Опыт работы|Навыки|Ключевые результаты|Образование|Общие сведения)\b",
        value,
        maxsplit=1,
        flags=re.I,
    )[0].strip(" ,;.-")

    value = re.sub(r"\s+", " ", value).strip(" ,;.-")
    return value


def _normalize_role_line(value: str) -> str:
    """Обрезка шума + «Role at Company» → только роль (если слева есть маркер должности)."""
    cleaned = _trim_role_noise(value)
    if not cleaned:
        return ""
    if re.search(r"\s+at\s+\S", cleaned, flags=re.I):
        left = re.split(r"\s+at\s+", cleaned, maxsplit=1, flags=re.I)[0].strip()
        if len(left) >= 6 and _ROLE_WORD_CORE_RE.search(left):
            cleaned = left
    return cleaned


def _normalize_role_case(value):
    value = _trim_role_noise(value)
    if not value:
        return ""

    for pattern, replacement in ROLE_CASE_RULES:
        if re.search(pattern, value, flags=re.I):
            value = re.sub(pattern, replacement, value, flags=re.I, count=1)
            break

    if value:
        value = value[0].upper() + value[1:]

    return value.strip()


def _is_tenure_or_prose_line(value: str) -> bool:
    """Стаж «N years…», предложения summary, длинный прозаический текст — не должность."""
    s = (value or "").strip()
    if not s:
        return True
    lower = s.lower()
    if re.match(r"^\s*\d", s):
        return True
    if re.search(r"\d+\+?\s*years?\b", lower):
        return True
    if re.search(r"\byears?\s+of\s+experience\b", lower):
        return True
    if re.search(r"\b\d+\+?\s*years?\s+in\b", lower):
        return True
    if re.search(r"\byears?\s+in\b", lower) and not re.search(
        r"\b(analyst|specialist|manager|director|lead|head|officer|engineer|consultant|controller|fp&a|fpa)\b",
        lower,
        flags=re.I,
    ):
        return True
    if "years" in lower and not re.search(
        r"\b(analyst|specialist|manager|director|lead|head|officer|engineer|consultant|controller|fp&a|fpa)\b",
        lower,
        flags=re.I,
    ):
        return True
    words = s.split()
    if len(words) > 14:
        return True
    if len(s) > 110:
        return True
    if s.count(".") > 1:
        return True
    if ". " in s and len(s) > 45:
        return True
    if s.endswith(".") and len(s) > 55 and "," in s:
        return True
    return False


def is_invalid_keyword_token(value: str) -> bool:
    """Не ключевое слово: prose, стаж, длинные фразы из summary."""
    v = (value or "").strip()
    if not v:
        return True
    if _is_resume_section_title_line(v.lower()):
        return True
    if _looks_like_email_or_phone_token(v):
        return True
    if _is_tenure_or_prose_line(v):
        return True
    if len(v) > 72:
        return True
    low = v.lower()
    if re.search(r"\byears?\b", low) and any(
        x in low for x in ("experience", " in ", " of ", "working", "including")
    ):
        return True
    if len(v.split()) > 8:
        return True
    return False


_LATIN_NAME_WORD = re.compile(r"^[A-Z][a-z]{1,24}$")
_CYR_NAME_WORD = re.compile(r"^[А-ЯЁ][а-яё]{1,24}$")


def _looks_like_person_name_only_line(line: str) -> bool:
    """2–4 слова в стиле ФИО без признаков должности."""
    s = (line or "").strip()
    words = s.split()
    if not (2 <= len(words) <= 4):
        return False
    if re.search(r"[\d@/]|linkedin|http", s, flags=re.I):
        return False
    if _HEADLINE_ROLE_PATTERN.search(s):
        return False
    for w in words:
        if not (_LATIN_NAME_WORD.match(w) or _CYR_NAME_WORD.match(w)):
            return False
    return True


def _is_probable_company_line(line: str) -> bool:
    l = (line or "").lower()
    return bool(
        re.search(
            r"\b(llc|ltd\.?|inc\.?|corp\.?|gmbh|s\.a\.|plc|ооо|зао|ао|пао|ип|group|holding|limited)\b",
            l,
            flags=re.I,
        )
    )


def _is_probable_education_line(line: str) -> bool:
    l = (line or "").lower()
    return bool(
        re.search(
            r"\b(bachelor|master|ph\.?d|mba|b\.?sc|m\.?sc|university|college|institute|"
            r"высшее\s+образование|магистр|бакалавр|аспирант|кандидат\s+наук)\b",
            l,
            flags=re.I,
        )
    )


def _is_sentence_like_role_line(line: str) -> bool:
    """Предложение summary, не заголовок должности."""
    s = (line or "").strip()
    l = s.lower()
    if re.search(
        r"\b(with|including|responsible|focusing|seeking|looking for|passionate|proven track)\b",
        l,
    ):
        return True
    if s.count(";") >= 1 and len(s.split()) > 10:
        return True
    if s.count(",") >= 3 and len(s.split()) > 10:
        return True
    return False


def _is_tools_list_line(line: str) -> bool:
    """Строка из инструментов через запятую без явной роли."""
    s = (line or "").strip()
    if s.count(",") < 3:
        return False
    if _HEADLINE_ROLE_PATTERN.search(s):
        return False
    if len(s.split(",")) > 5 and len(s) > 50:
        return True
    return False


def _is_probable_location_only_line(line: str) -> bool:
    """Короткая строка «только город/страна» без должности."""
    s = (line or "").strip()
    if len(s.split()) > 5:
        return False
    if _HEADLINE_ROLE_PATTERN.search(s):
        return False
    return bool(
        re.search(
            r"^(?:Abu Dhabi|Dubai|Sharjah|Riyadh|Moscow|London|Berlin|Munich|Frankfurt|Paris|"
            r"Singapore|Hong Kong|New York|Москва|Санкт-Петербург|Казань|Екатеринбург|"
            r"Дубай|ОАЭ|UAE|UK|USA|Remote)(?:\s*,\s*[A-Za-zА-Яа-яёЁ\s\-]+)?$",
            s,
            flags=re.I,
        )
    )


def _is_contact_or_link_line(line: str) -> bool:
    l = (line or "").lower()
    if "@" in line or "linkedin.com" in l or "tel:" in l or "e-mail" in l or "e-mail:" in l:
        return True
    if re.search(r"(?:\+7|8)[\d\s()\-]{9,}\d", line or ""):
        return True
    if re.search(r"\+\d{1,3}[\d\s\-]{8,}", line or ""):
        return True
    return bool(re.search(r"\b(?:whatsapp|telegram)\b", l))


def _looks_like_email_or_phone_token(value: str) -> bool:
    v = (value or "").strip()
    if "@" in v or re.search(r"^\+?[\d\s\-()]{10,}", v):
        return True
    return bool(re.search(r"linkedin|http|www\.", v, flags=re.I))


def _score_headline_line(line: str) -> int:
    score = 0
    if "/" in line or "|" in line:
        score += 8
    if re.search(r"\b(fp&a|fpa|fp\s*&\s*a)\b", line, flags=re.I):
        score += 5
    if re.search(r"\b(analyst|specialist|director|manager|lead|controller)\b", line, flags=re.I):
        score += 3
    ln = len(line)
    if ln <= 72:
        score += 2
    if ln > 92:
        score -= 5
    if line.count(",") > 2:
        score -= 4
    return score


def _looks_like_valid_role(value):
    cleaned = _normalize_role_line(value)
    if not cleaned:
        return False

    lower = cleaned.lower()

    if _is_resume_section_title_line(lower):
        return False

    if _is_tenure_or_prose_line(cleaned):
        return False

    if lower in ROLE_HEADER_ONLY:
        return False

    if lower in ROLE_INVALID_EXACT:
        return False

    if lower.startswith("и зарплат") or lower.startswith("зарплат"):
        return False

    if len(cleaned) < 3 or len(cleaned) > 160:
        return False

    if not _ROLE_WORD_CORE_RE.search(cleaned):
        return False

    if any(marker in lower for marker in ROLE_STOP_MARKERS):
        return False

    if any(marker in lower for marker in ROLE_JUNK_MARKERS):
        return False

    if re.search(r"\d{4,}", cleaned):
        return False

    words = re.findall(r"[a-zа-я0-9+#-]+", lower, flags=re.I)
    if len(words) > 12:
        return False

    if _looks_like_person_name_only_line(cleaned):
        return False
    if _is_probable_company_line(cleaned):
        return False
    if _is_probable_education_line(cleaned):
        return False
    if _is_probable_location_only_line(cleaned):
        return False
    if _is_contact_or_link_line(cleaned):
        return False
    if _is_sentence_like_role_line(cleaned):
        return False
    if _is_tools_list_line(cleaned):
        return False

    return True


def is_valid_role_candidate(value: str) -> bool:
    """True, если строка может быть должностью/headline, а не секцией/summary."""
    return bool(value and _looks_like_valid_role(value))


def _coerce_valid_position(candidate: str) -> str:
    c = _normalize_role_line(candidate)
    if not c or not is_valid_role_candidate(c):
        return ""
    return c


def _split_role_candidates(value):
    value = _trim_role_noise(value)
    if not value:
        return []

    parts = re.split(r"\s*/\s*|\s+\|\s+|\s*;\s*", value)
    candidates = []

    for part in parts:
        candidate = _normalize_role_case(part)
        if candidate and _looks_like_valid_role(candidate):
            candidates.append(candidate)

    unique = []
    seen = set()
    for item in candidates:
        key = item.lower()
        if key not in seen:
            seen.add(key)
            unique.append(item)

    return unique


def _score_role_candidate(candidate, summary_text):
    score = 0
    text = (candidate or "").lower()
    summary = (summary_text or "").lower()

    for pattern in ROLE_PRIORITY_PATTERNS:
        if re.search(pattern, text, flags=re.I):
            score += 3
            break

    if len(text) <= 60:
        score += 1

    for marker in ["директор", "руководитель", "head", "chief", "manager"]:
        if marker in text and marker in summary:
            score += 2

    if "сервис" in text:
        score += 2

    return score


def _choose_best_role(candidates, summary_text):
    if not candidates:
        return ""

    ranked = sorted(
        candidates,
        key=lambda item: (_score_role_candidate(item, summary_text), -len(item)),
        reverse=True,
    )
    return ranked[0]


def _pick_role_from_text(value, summary_text):
    candidates = _split_role_candidates(value)
    return _choose_best_role(candidates, summary_text)


def _pick_role_from_text_prefer_composite(value, summary_text):
    """Составная роль (A / B | C) сохраняется целиком, если строка валидна как headline."""
    v = _trim_role_noise(value)
    if not v:
        return ""
    if ("/" in v or "|" in v) and _looks_like_valid_role(v):
        return v.strip()
    return _pick_role_from_text(value, summary_text)


def _extract_headline_role_from_resume_top(resume_full: str) -> str:
    """Строка сразу под именем: короткий job-title, приоритет над секциями и summary."""
    if not resume_full:
        return ""
    lines = _split_lines(resume_full[:4000])[:14]
    scored: list[tuple[int, str]] = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        lower = line.lower()
        if _looks_like_person_name_only_line(line):
            continue
        if _is_probable_company_line(line):
            continue
        if _is_probable_location_only_line(line):
            continue
        if _is_probable_education_line(line):
            continue
        if _is_contact_or_link_line(line):
            continue
        if _is_resume_section_title_line(lower):
            continue
        if _is_tenure_or_prose_line(line):
            continue
        if "@" in line or re.search(r"https?://", lower):
            continue
        if re.search(r"(?:\+7|8)[\d\s()\-]{9,}\d", line):
            continue
        if len(line) > 95:
            continue
        if not _HEADLINE_ROLE_PATTERN.search(line):
            continue
        if not _looks_like_valid_role(line):
            continue
        sc = _score_headline_line(line)
        scored.append((sc, line))
    if not scored:
        return ""
    scored.sort(key=lambda item: (-item[0], len(item[1])))
    best_line = scored[0][1]
    return _coerce_valid_position(_pick_role_from_text_prefer_composite(best_line, "") or "")


def _pick_first_valid_role_from_lines(lines: list[str], summary_text: str, max_lines: int = 12) -> str:
    """Первая строка, похожая на должность (без заголовков секций и summary)."""
    for line in lines[:max_lines]:
        line = line.strip()
        if not line:
            continue
        lower_line = line.lower()
        if _is_resume_section_title_line(lower_line):
            continue
        if _is_tenure_or_prose_line(line):
            continue
        if _looks_like_person_name_only_line(line):
            continue
        if _is_probable_company_line(line):
            continue
        if _is_probable_location_only_line(line):
            continue
        if _is_contact_or_link_line(line):
            continue
        if _is_probable_education_line(line):
            continue
        if _is_sentence_like_role_line(line):
            continue
        if _is_tools_list_line(line):
            continue
        chosen = _coerce_valid_position(_pick_role_from_text_prefer_composite(line, summary_text))
        if chosen:
            return chosen
    return ""


def _extract_position_from_target_section(target_text, full_text, summary_text="", resume_full=""):
    rf = resume_full or ""
    headline = _extract_headline_role_from_resume_top(rf)
    if headline:
        return headline

    if (target_text or "").strip():
        from_target = _pick_first_valid_role_from_lines(_split_lines(target_text), summary_text, 10)
        if from_target:
            return from_target

    source = target_text or full_text or ""
    lines = _split_lines(source)

    for idx, line in enumerate(lines[:20]):
        lower_line = line.lower()

        if "желаемая должность и зарплата" in lower_line or lower_line == "желаемая должность":
            inline = re.split(r"желаемая должность(?:\s+и\s+зарплата)?\s*[:\-]?\s*", line, maxsplit=1, flags=re.I)
            if len(inline) == 2 and inline[1].strip():
                chosen = _coerce_valid_position(_pick_role_from_text_prefer_composite(inline[1], summary_text))
                if chosen:
                    return chosen

            if idx + 1 < len(lines):
                chosen = _coerce_valid_position(_pick_role_from_text_prefer_composite(lines[idx + 1], summary_text))
                if chosen:
                    return chosen

    patterns = [
        r"желаемая должность и зарплата\s*[:\-]\s*([^\n]{2,300})",
        r"желаемая должность\s*[:\-]\s*([^\n]{2,300})",
        r"\bцель\b\s*(?:\bдолжность\b\s*[:\-]?\s*)([^\n]{2,300})",
        r"\bдолжность\b(?!\s+и\s+зарплата)\s*[:\-]\s*([^\n]{2,300})",
        r"position\s*[:\-]\s*([^\n]{2,300})",
        r"objective\s*[:\-]\s*([^\n]{2,300})",
    ]

    for pattern in patterns:
        match = re.search(pattern, source, flags=re.I)
        if not match:
            continue
        chosen = _coerce_valid_position(_pick_role_from_text_prefer_composite(match.group(1), summary_text))
        if chosen:
            return chosen

    for line in lines[:12]:
        lower_line = line.lower()

        if lower_line in ROLE_HEADER_ONLY:
            continue

        if _is_resume_section_title_line(lower_line):
            continue

        if any(marker in lower_line for marker in ["желаемая должность", "зарплата", "занятость", "график"]):
            continue

        if _is_tenure_or_prose_line(line):
            continue

        chosen = _coerce_valid_position(_pick_role_from_text_prefer_composite(line, summary_text))
        if chosen:
            return chosen

    return ""


def _extract_employment_type(text):
    lower = (text or "").lower()

    explicit_match = re.search(
        r"(?:тип занятости|занятость)\s*[:\-]?\s*([^\n]{2,120})",
        text or "",
        flags=re.I,
    )
    explicit_value = explicit_match.group(1).lower() if explicit_match else ""

    if explicit_value:
        if any(token in explicit_value for token in ["полная занятость", "полный день", "full-time", "full time"]):
            return "full"
        if any(token in explicit_value for token in ["частичная занятость", "частичная", "part-time", "part time", "неполная"]):
            return "part"
        if any(token in explicit_value for token in ["проектная работа", "проектная занятость", "contract", "временная"]):
            return "project"

    return ""


def _extract_work_format(text):
    lower = (text or "").lower()

    found = []
    if "удален" in lower or "удаленн" in lower or "remote" in lower:
        found.append("remote")
    if "гибрид" in lower:
        found.append("hybrid")
    if "офис" in lower or "на месте работодателя" in lower:
        found.append("office")
    if "разъезд" in lower or "командиров" in lower:
        found.append("travel")

    if len(found) == 1:
        return found[0]
    if len(found) > 1:
        return "hybrid"
    return "office"


def _extract_salary(text):
    match = re.search(
        r"(?:зарплат[аы]|доход|ожидани[ея]|expectation|salary)[^0-9]{0,20}(\d{2,7})",
        text or "",
        flags=re.I,
    )
    if match:
        return match.group(1)

    match = re.search(r"(\d{2,7})\s*(?:руб|₽)", text or "", flags=re.I)
    return match.group(1) if match else ""


def _normalize_industry_label(value):
    cleaned = _clean_value(value or "", 120).lower()
    if not cleaned:
        return INDUSTRY_DEFAULT

    if cleaned in INDUSTRY_CANON_BY_LOWER:
        return INDUSTRY_CANON_BY_LOWER[cleaned]

    if cleaned in INDUSTRY_ALIASES:
        normalized = INDUSTRY_ALIASES[cleaned]
        if normalized in INDUSTRY_SET:
            return normalized

    for alias, canonical in INDUSTRY_ALIASES.items():
        if len(alias) >= 4 and alias in cleaned and canonical in INDUSTRY_SET:
            return canonical

    return INDUSTRY_DEFAULT


def _detect_industry(sections):
    weighted_sources = [
        (sections.get("target", ""), 4),
        (sections.get("summary", ""), 3),
        (sections.get("skills", ""), 2),
        (sections.get("experience", ""), 2),
        (sections.get("education", ""), 1),
    ]

    scores = {}
    for source, weight in weighted_sources:
        if not source:
            continue
        for pattern, label in INDUSTRY_RULES:
            hits = re.findall(pattern, source, flags=re.I)
            if hits:
                scores[label] = scores.get(label, 0) + len(hits) * weight

    service_focus_text = "\n".join([sections.get("target", ""), sections.get("summary", "")]).lower()
    supply_chain_focus_text = "\n".join([sections.get("target", ""), sections.get("summary", "")]).lower()
    if re.search(
        r"\b(директор по управлению цепочками поставок|управление цепочками поставок|цепочки поставок|цепочками поставок|supply chain|scm|директор по закупкам|директор по логистике)\b",
        supply_chain_focus_text,
        flags=re.I,
    ):
        scores["Логистика / Закупки / Supply Chain"] = scores.get("Логистика / Закупки / Supply Chain", 0) + 10

    if re.search(
        r"\b(директор по сервису|руководител[ья] сервиса|head of service|service director|customer service|service operations|послепродажн(ый|ого) сервис)\b",
        service_focus_text,
        flags=re.I,
    ):
        scores["Операционное управление"] = scores.get("Операционное управление", 0) + 8

    if not scores:
        return INDUSTRY_DEFAULT

    ranked = sorted(
        scores.items(),
        key=lambda item: (-item[1], INDUSTRY_ORDER.get(item[0], 999)),
    )

    best_label, best_score = ranked[0]
    if best_score < 2:
        return INDUSTRY_DEFAULT

    return _normalize_industry_label(best_label)


def _extract_keywords(sections, position, industry):
    combined = "\n".join([
        sections.get("summary", ""),
        sections.get("skills", ""),
        sections.get("experience", ""),
        sections.get("target", ""),
    ]).lower()

    normalized_industry = _normalize_industry_label(industry)

    industry_to_keywords = {
        "Финансы": ["финансы", "бюджетирование", "отчетность", "управленческий учет", "fp&a", "ifrs"],
        "Управление персоналом": ["hr", "подбор персонала", "обучение персонала", "организационное развитие", "c&b"],
        "Продажи / Развитие бизнеса": ["продажи", "развитие бизнеса", "b2b", "key account", "переговоры"],
        "Маркетинг / PR / Бренд": ["маркетинг", "бренд", "pr", "коммуникации", "performance marketing"],
        "Операционное управление": ["операционное управление", "сервис", "клиентский сервис", "оптимизация процессов", "kpi", "lean"],
        "Логистика / Закупки / Supply Chain": ["управление цепочками поставок", "логистика", "закупки", "supply chain", "scm", "управление запасами"],
        "Производство / Инжиниринг": ["производство", "инжиниринг", "техническое управление", "качество"],
        "Проектное управление": ["управление проектами", "project management", "pmo", "risk management"],
        "IT / Digital / Product": ["product management", "digital", "erp", "crm", "data analytics"],
        "Юриспруденция / Compliance": ["legal", "compliance", "договорная работа", "регуляторика"],
        "Туризм / Гостеприимство": ["туризм", "hospitality", "travel management", "client experience"],
        "HoReCa / Ресторанный бизнес": ["horeca", "ресторанный бизнес", "f&b", "service standards"],
        "Гостиничный бизнес": ["гостиничный бизнес", "hotel operations", "guest experience", "front office"],
        "FMCG / Retail / Пищевая отрасль": ["fmcg", "retail", "категорийный менеджмент", "мерчандайзинг"],
        "Энергетика / Нефтегаз": ["энергетика", "нефтегаз", "добыча", "промышленная безопасность"],
        "Медицина / Фарма": ["медицина", "фарма", "healthcare", "clinical", "gmp"],
        "Строительство / Девелопмент / Недвижимость": ["строительство", "девелопмент", "недвижимость", "технадзор"],
        "Образование": ["образование", "методология", "преподавание", "e-learning"],
        "Государственный сектор": ["государственный сектор", "госуправление", "регламент", "госзакупки"],
        "Консалтинг": ["консалтинг", "advisory", "strategy", "change management"],
        "Другое": [],
    }

    found = []

    if position and len(position.split()) <= 6:
        found.append(position.lower())

    for item in industry_to_keywords.get(normalized_industry, []):
        if item not in found:
            found.append(item)

    for marker in GENERIC_KEYWORD_MARKERS:
        if marker in combined and marker not in found:
            found.append(marker)

    cleaned = []
    seen = set()
    for item in found:
        value = _clean_value(item, 80).lower()
        if not value:
            continue
        if value in KEYWORD_STOP_WORDS:
            continue
        if any(bad in value for bad in ROLE_JUNK_MARKERS):
            continue
        if re.search(r"\d{4,}", value):
            continue
        if value in seen:
            continue
        seen.add(value)
        cleaned.append(value)

    return ", ".join(cleaned[:8])


def map_resume_to_form_data(text):
    cleaned_text = _clean_text(text)
    sections = split_resume_sections(cleaned_text)

    contacts_source = "\n".join([
        sections.get("contacts", ""),
        cleaned_text[:1200],
    ])

    target_source = sections.get("target", "")
    summary_source = sections.get("summary", "")
    top_source = "\n".join([
        sections.get("target", ""),
        sections.get("summary", ""),
        cleaned_text[:1500],
    ])

    position = _extract_position_from_target_section(target_source, top_source, summary_source, cleaned_text)
    email = _extract_email(contacts_source)
    location = _extract_location(contacts_source)
    salary_min = _extract_salary(target_source or cleaned_text[:1200])
    employment_type = _extract_employment_type(target_source or cleaned_text[:1200])
    work_format = _extract_work_format(target_source or cleaned_text[:1200])

    industry_raw = _detect_industry(sections)
    industry = _normalize_industry_label(industry_raw)
    if industry not in INDUSTRY_SET:
        industry = INDUSTRY_DEFAULT

    keywords = _extract_keywords(sections, position, industry)

    lower = cleaned_text.lower()
    remote = (
        work_format == "remote"
        or "remote" in lower
        or "удален" in lower
        or "удаленн" in lower
    )

    return {
        "email": email,
        "query_text": industry,
        "position": position,
        "keywords": keywords,
        "location": location,
        "salary_min": salary_min,
        "salary_max": "",
        "employment_type": employment_type,
        "work_format": work_format,
        "display_period": "",
        "sort_order": "",
        "vacancy_source": "",
        "remote": remote,
        "debug_sections": sections,
    }
