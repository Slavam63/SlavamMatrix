"""Регрессия на production-like finance CV (UAE): секция Professional Summary не должна стать должностью."""
from __future__ import annotations

import json
import unittest
from pathlib import Path

from app.form_recommendation_agent import FormRecommendationAgent

FIXTURE = Path(__file__).resolve().parent / "fixtures" / "form_recommendation_problematic_finance_uae_cv.txt"


class ProblematicFinanceUAEProductionLikeTests(unittest.TestCase):
    """Кейс из реального класса ошибок: headline + Professional Summary + Abu Dhabi + finance skills."""

    def setUp(self):
        self.text = FIXTURE.read_text(encoding="utf-8")
        self.agent = FormRecommendationAgent()

    def test_fixture_file_exists(self):
        self.assertTrue(FIXTURE.is_file(), f"Missing fixture: {FIXTURE}")

    def test_professional_summary_not_position(self):
        r = self.agent.recommend(self.text).to_dict()
        pos = (r.get("position") or "").lower()
        self.assertNotEqual(pos.strip(), "professional summary")
        self.assertNotIn("professional summary", pos)

    def test_finance_role_extracted(self):
        r = self.agent.recommend(self.text).to_dict()
        pos = (r.get("position") or "").lower()
        self.assertTrue(
            "finance" in pos or "fp&a" in pos or "analyst" in pos,
            msg=f"Expected finance role markers, got: {r.get('position')!r}",
        )

    def test_email_and_abu_dhabi(self):
        r = self.agent.recommend(self.text).to_dict()
        self.assertEqual((r.get("email") or "").lower(), "john.doe@finance-uae.ae")
        self.assertIn("Abu Dhabi", r.get("location") or "")

    def test_query_text_no_section_titles(self):
        r = self.agent.recommend(self.text).to_dict()
        qt = (r.get("query_text") or "").lower()
        self.assertNotIn("professional summary", qt)
        self.assertNotIn("experience", qt)
        self.assertNotIn("education", qt)

    def test_keywords_finance_markers(self):
        r = self.agent.recommend(self.text).to_dict()
        blob = " ".join(r.get("keywords") or []).lower()
        self.assertTrue(any(x in blob for x in ("fp&a", "ifrs", "budget", "forecast", "excel")))

    def test_warnings_acceptable(self):
        r = self.agent.recommend(self.text).to_dict()
        w = " ".join(r.get("warnings") or []).lower()
        # Не должно быть ложных «нет email/локации», если они извлечены
        if r.get("email") and r.get("location"):
            self.assertNotIn("не найден e-mail", w)
            self.assertNotIn("локация не обнаружена", w)

    def test_json_roundtrip_script_shape(self):
        """Проверка, что to_dict() сериализуется (как в scripts/run_form_recommendation_fixture)."""
        r = self.agent.recommend(self.text).to_dict()
        r.pop("extracted_facts", None)
        json.dumps(r, ensure_ascii=False)


if __name__ == "__main__":
    unittest.main()
