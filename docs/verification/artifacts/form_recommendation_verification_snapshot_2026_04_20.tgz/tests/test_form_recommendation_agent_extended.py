"""Расширенные сценарии FormRecommendationAgent: разные языки, структуры, регрессии."""
import unittest

from app.form_recommendation_agent import FormRecommendationAgent


class FormRecommendationAgentExtendedTests(unittest.TestCase):
    def setUp(self):
        self.agent = FormRecommendationAgent()

    # A — англ. finance
    def test_a_english_finance_cv(self):
        cv = """
        Jane Doe
        Finance Analyst / FP&A Specialist
        Abu Dhabi | jane@fin.com
        Skills: Excel, IFRS, fp&a, budgeting
        """
        r = self.agent.recommend(cv).to_dict()
        self.assertIn("Finance", r["position"])
        self.assertIn("FP&A", r["query_text"])
        self.assertIn("Abu Dhabi", r["query_text"])
        self.assertTrue(r.get("email"))

    # B — русский finance
    def test_b_russian_finance_cv(self):
        cv = """
        Иван Петров
        Финансовый аналитик / FP&A
        Москва, ivan@mail.ru
        Навыки: IFRS, бюджетирование, Excel
        """
        r = self.agent.recommend(cv).to_dict()
        self.assertTrue("аналитик" in r["position"].lower() or "fp&a" in r["position"].lower())
        self.assertTrue(r.get("email"))

    # C — имя + headline + контакты
    def test_c_name_headline_contacts_top_block(self):
        cv = """
        Maria Ivanova
        Head of Business Development
        +971501234567
        maria@corp.ae
        Dubai
        Summary: B2B sales leader.
        """
        r = self.agent.recommend(cv).to_dict()
        self.assertIn("Business Development", r["position"])
        self.assertNotEqual(r["position"].lower(), "maria ivanova")

    # D — Professional Summary как секция
    def test_d_professional_summary_section(self):
        cv = """
        John Smith
        Commercial Director
        London
        Professional Summary
        Driving revenue across EMEA.
        """
        r = self.agent.recommend(cv).to_dict()
        self.assertNotIn("professional summary", r["position"].lower())
        self.assertNotIn("professional summary", (r.get("query_text") or "").lower())

    # E — роль только в headline
    def test_e_role_only_headline(self):
        cv = """
        Alex Lee
        Chief Financial Officer (CFO)
        Singapore
        """
        r = self.agent.recommend(cv).to_dict()
        pos = (r.get("position") or "").upper()
        self.assertTrue("CFO" in pos or "FINANCIAL" in pos or "CHIEF" in pos)

    # F — роль только в опыте (слабый верх)
    def test_f_role_from_experience_fallback(self):
        cv = """
        Peter Brown
        Moscow
        Experience
        2020-present
        Senior Product Manager at X LLC
        Built roadmap.
        """
        r = self.agent.recommend(cv).to_dict()
        pos = r.get("position") or ""
        self.assertIn("Product", pos)
        self.assertIn("Manager", pos)

    # G — mixed RU/EN
    def test_g_mixed_language_cv(self):
        cv = """
        Сергей Sidorov
        Director of Economics and Finance
        Москва serg@yandex.ru
        Skills: ERP, budgeting
        """
        r = self.agent.recommend(cv).to_dict()
        self.assertTrue("Director" in r["position"] or "директор" in r["position"].lower())

    # H — несколько ролей через slash
    def test_h_slash_composite_role(self):
        cv = """
        Tom H
        Finance Analyst / FP&A Specialist
        Berlin
        """
        r = self.agent.recommend(cv).to_dict()
        self.assertIn("/", r["position"])
        self.assertIn("FP&A", r["query_text"])

    # I — много skills, не должность
    def test_i_skills_block_not_position(self):
        cv = """
        User X
        Excel, Python, SAP, Oracle, SQL, Power BI, Tableau
        Moscow
        """
        r = self.agent.recommend(cv).to_dict()
        self.assertNotEqual(r["position"].lower().strip(), "excel, python, sap, oracle, sql, power bi, tableau")

    # J — без email
    def test_j_no_email(self):
        cv = """
        Anna
        Marketing Manager
        Paris
        """
        r = self.agent.recommend(cv).to_dict()
        self.assertIn("e-mail", " ".join(r.get("warnings") or []).lower()) or not r.get("email")

    # K — без location
    def test_k_no_location(self):
        cv = """
        Bob
        HR Director
        bob@co.com
        """
        r = self.agent.recommend(cv).to_dict()
        w = " ".join(r.get("warnings") or []).lower()
        self.assertTrue("локац" in w or not r.get("location"))

    # L — plain text плохая структура
    def test_l_plain_text_chaos(self):
        cv = "random text then Director of Sales then more noise " * 3 + " dubai sales@x.com"
        r = self.agent.recommend(cv).to_dict()
        self.assertIsNotNone(r.get("position"))


class FormRecommendationAgentRegressionTests(unittest.TestCase):
    def setUp(self):
        self.agent = FormRecommendationAgent()

    def test_never_professional_summary_as_position(self):
        r = self.agent.recommend(
            """
            X Y
            Professional Summary
            Analyst
            """
        ).to_dict()
        self.assertNotEqual((r.get("position") or "").lower().strip(), "professional summary")

    def test_never_core_competencies_as_position(self):
        r = self.agent.recommend(
            """
            A B
            Core Competencies
            FP&A
            """
        ).to_dict()
        self.assertNotEqual((r.get("position") or "").lower().strip(), "core competencies")

    def test_never_abu_dhabi_as_position(self):
        r = self.agent.recommend(
            """
            John
            Abu Dhabi
            Finance Analyst
            """
        ).to_dict()
        self.assertNotEqual((r.get("position") or "").strip(), "Abu Dhabi")

    def test_linkedin_not_position(self):
        r = self.agent.recommend(
            """
            Name Here
            Finance Manager
            linkedin.com/in/foo
            """
        ).to_dict()
        self.assertNotIn("linkedin", (r.get("position") or "").lower())

    def test_email_not_in_keywords(self):
        r = self.agent.recommend(
            """
            P Q
            Analyst
            Moscow
            Skills: x@y.com, Excel
            """
        ).to_dict()
        for k in r.get("keywords") or []:
            self.assertNotIn("@", k)

    def test_section_title_mix_not_in_query(self):
        r = self.agent.recommend(
            """
            U V
            Commercial Lead
            Dubai
            Professional Summary
            ERP IFRS
            """
        ).to_dict()
        qt = (r.get("query_text") or "").lower()
        self.assertNotIn("professional summary", qt)


if __name__ == "__main__":
    unittest.main()
