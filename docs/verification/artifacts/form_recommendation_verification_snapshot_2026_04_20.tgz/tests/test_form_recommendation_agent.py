import unittest

from app.form_recommendation_agent import FormRecommendationAgent


class FormRecommendationAgentTests(unittest.TestCase):
    def setUp(self):
        self.agent = FormRecommendationAgent()

    def test_desired_role_wins_over_past_roles(self):
        resume_text = """
        Иван Иванов
        ivan@example.com
        Москва

        Желаемая должность
        Директор по ИТ

        Опыт работы
        2021 - н.в.
        Исполнительный директор
        2018 - 2021
        Операционный директор

        Профессиональные навыки
        ERP, SAP, цифровая трансформация, PostgreSQL
        """

        result = self.agent.recommend(resume_text).to_dict()

        self.assertEqual(result["primary_role"], "Директор по ИТ")
        self.assertEqual(result["industry"], "IT / Digital / Product")
        self.assertIn("Москва", result["query_text"])

    def test_manual_input_has_priority(self):
        resume_text = """
        Петр Петров
        petr@example.com
        Москва

        Желаемая должность
        Финансовый директор
        """

        result = self.agent.recommend(
            resume_text,
            user_form_data={
                "position": "Коммерческий директор",
                "industry": "Продажи / Развитие бизнеса",
                "location": "Санкт-Петербург",
                "email": "manual@example.com",
                "keywords": "b2b, crm",
            },
        ).to_dict()

        self.assertEqual(result["position"], "Коммерческий директор")
        self.assertEqual(result["industry"], "Продажи / Развитие бизнеса")
        self.assertEqual(result["location"], "Санкт-Петербург")
        self.assertEqual(result["email"], "manual@example.com")
        self.assertEqual(result["keywords"], ["b2b", "crm"])

    def test_query_text_is_search_string_not_industry(self):
        resume_text = """
        Сергей Сергеев
        sergey@example.com
        Москва

        Желаемая должность
        Директор по ИТ

        Профессиональные навыки
        ERP, SAP, цифровая трансформация, PostgreSQL
        """

        result = self.agent.recommend(resume_text).to_dict()

        self.assertNotEqual(result["query_text"], result["industry"])
        self.assertTrue(result["query_text"].startswith("Директор по ИТ"))

    def test_composite_finance_query_includes_location_and_variants(self):
        resume_text = """
        Jane Doe
        Finance Analyst / FP&A Specialist
        Abu Dhabi

        Summary
        FP&A, budgeting, forecasting.
        """

        result = self.agent.recommend(resume_text).to_dict()

        self.assertEqual(result["query_text"], "Finance Analyst FP&A Abu Dhabi")
        self.assertLessEqual(len(result["query_text"].split()), 6)
        variants = result.get("query_text_variants") or []
        self.assertTrue(any("FP&A Analyst" in v for v in variants))
        self.assertTrue(any("Financial Planning" in v for v in variants))
        self.assertIn("warnings", result)

    def test_section_title_never_becomes_position(self):
        resume_text = """
        John Doe
        Finance Analyst / FP&A Specialist
        Professional Summary
        Led budgeting and forecasting for regional HQ.
        Abu Dhabi
        john@example.com
        Skills: Excel, IFRS
        """
        result = self.agent.recommend(resume_text).to_dict()
        self.assertNotEqual(
            (result.get("position") or "").lower(),
            "professional summary",
        )
        self.assertNotIn("professional summary", (result.get("query_text") or "").lower())


if __name__ == "__main__":
    unittest.main()
